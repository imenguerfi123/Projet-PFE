from flask import Flask,  request
from flask_restplus import Api, Resource, fields
from werkzeug.contrib.fixers import ProxyFix
from functools import wraps 


def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):

        token = None

        if 'X-API-KEY' in request.headers:
            token = request.headers['X-API-KEY']

        if not token:
            return {'message' : 'Token is missing.'}, 401

        if token != 'mytoken':
            return {'message' : 'Your token is wrong, wrong, wrong!!!'}, 401

        print('TOKEN: {}'.format(token))
        return f(*args, **kwargs)

    return decorated

ns_terminal = api.namespace('Terminals', description='Terminals operations')


terminal = api.model('terminals', {
    'id': fields.Integer(readonly=True, description='The card unique identifier'),
    'Device_id': fields.String(required=True, description='The card details')
})


#Terminals
class TerminalDAO(object):
    def __init__(self):
        self.counter = 0
        self.terminals = []
        self.nbr_Probes_max= 2

    def get_terminal_by_id(self, probe_id):
        ''' Fetch terminal
            :return terminal
            id: integer
            Device_id: str
        ''' 
        for terminal in self.terminals:
            if terminal['id'] == probe_id:
                return terminal
        api.abort(404, "terminal {} doesn't exist".format(probe_id))

    def create_terminal(self, data):
        ''' create a new terminal
            dictionary(e.g:{"Device_id":"1"}
        ''' 
        if self.counter < self.nbr_Probes_max :
            terminal = data
            self.terminals.append(terminal)
            terminal['id'] = self.counter = self.counter + 1
            return terminal
        api.abort(500, "The maximum number of probes has been exceeded .")

    def update_terminal(self, probe_id, data):
        ''' Update a terminal given its identifier "probe_id" 
        ''' 
        terminal = self.get_terminal_by_id(probe_id)
        terminal.update(data)
        return terminal

    def delete_terminal(self, probe_id):
        ''' Delete a terminal given its identifier "probe_id" 
        '''
        terminal = self.get_terminal_by_id(probe_id)
        self.terminals.remove(terminal)


DAOT = TerminalDAO()
DAOT.create_terminal({'Device_id': '1'})



@ns_terminal.route('/')
class TerminalList(Resource):
    ''' Shows a list of all terminals, and lets you POST to add new terminals
    '''
    @api.doc(security='apikey')
    @token_required
    @ns_terminal.doc('list_terminals')
    @ns_terminal.marshal_list_with(terminal, envelope='terminals')
    def get(self):
        ''' List all terminals
        '''
        return DAOT.terminals
     
    @api.doc(security='apikey')
    @token_required
    @ns_terminal.doc('create_terminal')
    @ns_terminal.expect(terminal)
    @ns_terminal.marshal_with(terminal, code=201)
    def post(self):
        ''' Create a new terminal
        '''
        return DAOT.create_terminal(api.payload), 201


@ns_terminal.route('/<int:probe_id>')
@ns_terminal.response(404, 'Terminal not found')
@ns_terminal.param('probe_id', 'The terminal identifier')
class Terminal(Resource):
    ''' Show a single terminal item and lets you delete them
    '''
    @api.doc(security='apikey')
    @token_required
    @ns_terminal.doc('get_terminal')
    @ns_terminal.marshal_with(terminal)
    def get(self, probe_id):
        ''' Fetch a given resource
        '''
        return DAOT.get_terminal_by_id(probe_id)
     
    @api.doc(security='apikey')
    @token_required
    @ns_terminal.doc('delete_terminal')
    @ns_terminal.response(204, 'Terminal deleted')
    def delete(self, probe_id):
        ''' Delete a terminal given its identifier
        '''
        DAOT.delete_terminal(probe_id)
        return '', 204
    
    @api.doc(security='apikey')
    @token_required
    @ns_terminal.expect(terminal)
    @ns_terminal.marshal_with(terminal)
    def put(self, probe_id):
        ''' Update a card given its identifier
        '''
        return DAOT.update_terminal(probe_id, api.payload)
from flask import Flask,  request
from flask_restplus import Api, Resource, fields
from werkzeug.contrib.fixers import ProxyFix
from functools import wraps 
from card import *
from terminal import *
from channel import *

app = Flask(__name__)
app.wsgi_app = ProxyFix(app.wsgi_app)

authorizations = {
    'apikey' : {
        'type' : 'apiKey',
        'in' : 'header',
        'name' : 'X-API-KEY'
    }
}

api = Api(app, authorizations=authorizations, version='1.0', title='Multiplexing API',
    description='A simple Multiplexing API',
)


if __name__ == '__main__':
    app.run(debug=True)
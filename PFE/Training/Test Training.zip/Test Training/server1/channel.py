from flask import Flask,  request
from flask_restplus import Api, Resource, fields
from werkzeug.contrib.fixers import ProxyFix
from functools import wraps 

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):

        token = None

        if 'X-API-KEY' in request.headers:
            token = request.headers['X-API-KEY']

        if not token:
            return {'message' : 'Token is missing.'}, 401

        if token != 'mytoken':
            return {'message' : 'Your token is wrong, wrong, wrong!!!'}, 401

        print('TOKEN: {}'.format(token))
        return f(*args, **kwargs)

    return decorated
	
	
ns_channel = api.namespace('Channels', description='Channels operations')

channel = api.model('channels', {
    'id': fields.Integer(readonly=True, description='The channel unique identifier'),
    'Card_id': fields.String(required=True, description='The channel details'),
    'Terminal_id': fields.String(required=True, description='The channel details')
})


#Channels
class ChannelDAO(object):
    def __init__(self):
        self.counter = 0
        self.channels = []
        self.nbr_Probes_max= 2

    def get_channel_by_id(self, channel_id):   
        ''' Fetch channel
            :return a channel given its identifier
            id: integer
            Card_id: string
            Terminal_id: string
        '''
        for channel in self.channels:
            if channel['id'] == channel_id:
                return channel
        api.abort(404, "channel {} doesn't exist".format(channel_id))

    def create_channel(self, data):
        '''create a new channel 
         dictionary(e.g:{"Card_id":"1", "Terminal_id":"3"}
        ''' 
        if self.counter < self.nbr_Probes_max :
            channel = data
            self.channels.append(channel)
            channel['id'] = self.counter = self.counter + 1
            return channel
        if self.counter == self.nbr_Probes_max :
            api.abort(500, "The number of channels is exactly equal to the numbers of the probes.")

    def update_channel(self, channel_id, data):
        ''' Update a channel given its identifier "channel_id" 
        '''
        channel = self.get_channel_by_id(channel_id)
        channel.update(data)
        return channel

    def delete_channel(self, channel_id):
        ''' Delete a channel given its identifier "channel_id" 
        '''
        channel = self.get_channel_by_id(channel_id)
        self.channels.remove(channel)


DAOC = ChannelDAO()
DAOC.create_channel({'Card_id': '1', 'Terminal_id': '2' })


@ns_channel.route('/')
class ChannelList(Resource):
    ''' Shows a list of all channels, and lets you POST to add new channels
    '''
    @api.doc(security='apikey')
    @token_required
    @ns_channel.doc('list_channels')
    @ns_channel.marshal_list_with(channel, envelope='channels')
    def get(self):
        ''' List all channels
        '''
        return DAOC.channels
     
    @api.doc(security='apikey')
    @token_required
    @ns_channel.doc('create_channel')
    @ns_channel.expect(channel)
    @ns_channel.marshal_with(channel, code=201)
    def post(self):
        ''' Create a new channel
        '''
        return DAOC.create_channel(api.payload), 201


@ns_channel.route('/<int:channel_id>')
@ns_channel.response(404, 'Channel not found')
@ns_channel.param('channel_id', 'The channel identifier')
class Channel(Resource):
    ''' Show a single channel item and lets you delete them
    '''
    @api.doc(security='apikey')
    @token_required
    @ns_channel.doc('get_channel')
    @ns_channel.marshal_with(channel)
    def get(self, channel_id):
        ''' Fetch a given resource
        '''
        return DAOC.get_channel_by_id(channel_id)
     
    @api.doc(security='apikey')
    @token_required
    @ns_channel.doc('delete_channel')
    @ns_channel.response(204, 'Channel deleted')
    def delete(self, channel_id):
        ''' Delete a channel given its identifier
        '''
        DAOC.delete_channel(channel_id)
        return '', 204
     
    @api.doc(security='apikey')
    @token_required
    @ns_channel.expect(channel)
    @ns_channel.marshal_with(channel)
    def put(self, channel_id):
        ''' Update a channel given its identifier
        '''
        return DAOC.update_channel(channel_id, api.payload)

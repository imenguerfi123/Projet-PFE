#!flask/bin/python

"""Alternative version of  RESTful server implemented using the
Flask-RESTful extension."""

from flask import Flask, jsonify, abort, make_response
from flask_restful import Api, Resource, reqparse, fields, marshal
from flask_httpauth import HTTPBasicAuth

app = Flask(__name__, static_url_path="")
api = Api(app)
auth = HTTPBasicAuth()


@auth.get_password
def get_password(username):
    if username == 'imen':
        return 'python'
    return None


@auth.error_handler
def unauthorized():
    # return 403 instead of 401 to prevent browsers from displaying the default
    # auth dialog
    return make_response(jsonify({'message': 'Unauthorized access'}), 403)

cards = [
    {
        'id': 1,
        'Name': u'Visa'

    },
    {
        'id': 2,
        'Name': u'MasterCard'
    },
    {
        'id': 3,
        'Name': u'Maestro'

    },
    {
        'id': 4,
        'Name': u'BlueVisa'
    }
]

terminals = [
    {
        'id': 1,
        'Device_id': u'T1'
    },
    {
        'id': 2,
        'Device_id': u'T2'
    }
]

channels = [
    {
        'id': 1,
        'cardId': u'1',
        'terminalId': u'2'
    },
    {
        'id': 2,
        'cardId': u'2',
        'terminalId': u'1'
    }
]

card_fields = {
    'Name': fields.String,
    'uri': fields.Url('card')
}

terminal_fields = {
    'Device_id': fields.String,
    'uri': fields.Url('terminal')
}

channel_fields = {
    'cardId': fields.String,
    'terminalId': fields.String,
    'uri': fields.Url('channel')
}

#Card
class CardListAPI(Resource):
    decorators = [auth.login_required]

    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        self.reqparse.add_argument('Name', type=str, required=True,
                                   help='No card name provided',
                                   location='json')
        super(CardListAPI, self).__init__()

    def get(self):
        return {'cards': [marshal(card, card_fields) for card in cards]}

    def post(self):
        args = self.reqparse.parse_args()
        card = {
            'id': cards[-1]['id'] + 1 if len(cards) > 0 else 1,
            'Name': args['Name'],
        }
        cards.append(card)
        return {'card': marshal(card, card_fields)}, 201


class CardAPI(Resource):
    decorators = [auth.login_required]

    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        self.reqparse.add_argument('Name', type=str, location='json')
        super(CardAPI, self).__init__()

    def get(self, id):
        card = [card for card in cards if card['id'] == id]
        if len(card) == 0:
            abort(404)
        return {'card': marshal(card[0], card_fields)}

    def put(self, id):
        card = [card for card in cards if card['id'] == id]
        if len(card) == 0:
            abort(404)
        card = card[0]
        args = self.reqparse.parse_args()
        for k, v in args.items():
            if v is not None:
                card[k] = v
        return {'card': marshal(card, card_fields)}

    def delete(self, id):
        card = [card for card in cards if card['id'] == id]
        if len(card) == 0:
            abort(404)
        cards.remove(card[0])
        return {'result': True}

#terminal
class TerminalListAPI(Resource):
    decorators = [auth.login_required]

    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        self.reqparse.add_argument('Device_id', type=str, required=True,
                                   help='No device id provided',
                                   location='json')
        super(TerminalListAPI, self).__init__()

    def get(self):
        return {'terminals': [marshal(terminal, terminal_fields) for terminal in terminals]}

    def post(self):
        args = self.reqparse.parse_args()
        terminal = {
            'id': terminals[-1]['id'] + 1 if len(terminals) > 0 else 1,
            'Device_id': args['Device_id'],
        }
        terminals.append(terminal)
        return {'terminal': marshal(terminal, terminal_fields)}, 201


class TerminalAPI(Resource):
    decorators = [auth.login_required]

    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        self.reqparse.add_argument('Device_id', type=str, location='json')
        super(TerminalAPI, self).__init__()

    def get(self, id):
        terminal = [terminal for terminal in terminals if terminal['id'] == id]
        if len(terminal) == 0:
            abort(404)
        return {'terminal': marshal(terminal[0], terminal_fields)}

    def put(self, id):
        terminal = [terminal for terminal in terminals if terminal['id'] == id]
        if len(terminal) == 0:
            abort(404)
        terminal = terminal[0]
        args = self.reqparse.parse_args()
        for k, v in args.items():
            if v is not None:
                terminal[k] = v
        return {'terminal': marshal(terminal, terminal_fields)}

    def delete(self, id):
        terminal = [terminal for terminal in terminals if terminal['id'] == id]
        if len(terminal) == 0:
            abort(404)
        terminals.remove(terminal[0])
        return {'result': True}
 
 
 
 #channel
class ChannelListAPI(Resource):
    decorators = [auth.login_required]

    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        self.reqparse.add_argument('cardId', type=str, required=True,
                                   help='No card id provided',
                                   location='json')
        self.reqparse.add_argument('terminalId', type=str, required=True,
                                   help='No terminal id provided',
                                   location='json')                          
        super(ChannelListAPI, self).__init__()

    def get(self):
        return {'channels': [marshal(channel, channel_fields) for channel in channels]}

    def post(self):
        args = self.reqparse.parse_args()
        channel = {
            'id': channels[-1]['id'] + 1 if len(channels) > 0 else 1,
            'cardId': args['cardId'],
            'terminalId': args['terminalId'],
        }
        channels.append(channel)
        return {'channel': marshal(channel, channel_fields)}, 201


class ChannelAPI(Resource):
    decorators = [auth.login_required]

    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        self.reqparse.add_argument('Device_id', type=str, location='json')
        super(ChannelAPI, self).__init__()

    def get(self, id):
        channel = [channel for channel in channels if channel['id'] == id]
        if len(channel) == 0:
            abort(404)
        return {'channel': marshal(channel[0], channel_fields)}

    def put(self, id):
        channel = [channel for channel in channels if channel['id'] == id]
        if len(channel) == 0:
            abort(404)
        channel = channel[0]
        args = self.reqparse.parse_args()
        for k, v in args.items():
            if v is not None:
                channel[k] = v
        return {'channel': marshal(channel, channel_fields)}

    def delete(self, id):
        channel = [channel for channel in channels if channel['id'] == id]
        if len(channel) == 0:
            abort(404)
        channels.remove(channel[0])
        return {'result': True}
        
        
api.add_resource(CardListAPI, '/todo/api/v1.0/cards', endpoint='cards')
api.add_resource(CardAPI, '/todo/api/v1.0/cards/<int:id>', endpoint='card')
api.add_resource(TerminalListAPI, '/todo/api/v1.0/terminals', endpoint='terminals')
api.add_resource(TerminalAPI, '/todo/api/v1.0/terminals/<int:id>', endpoint='terminal')
api.add_resource(ChannelListAPI, '/todo/api/v1.0/channels', endpoint='channels')
api.add_resource(ChannelAPI, '/todo/api/v1.0/channels/<int:id>', endpoint='channel')

if __name__ == '__main__':
    app.run(debug=True)

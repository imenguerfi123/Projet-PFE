#!flask/bin/python
from flask import Flask, jsonify, abort, request, make_response, url_for
from flask_httpauth import HTTPBasicAuth

app = Flask(__name__, static_url_path = "")
auth = HTTPBasicAuth()

@auth.get_password
def get_password(username):
    if username == 'imen':
        return 'python'
    return None

@auth.error_handler
def unauthorized():
    return make_response(jsonify( { 'error': 'Unauthorized access' } ), 403)
    # return 403 instead of 401 to prevent browsers from displaying the default auth dialog
    
@app.errorhandler(400)
def not_found(error):
    return make_response(jsonify( { 'error': 'Bad request' } ), 400)

@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify( { 'error': 'Not found' } ), 404)


cards = [
    {
        'id': 1,
        'Name': u'Visa'

    },
    {
        'id': 2,
        'Name': u'MasterCard'
    },
    {
        'id': 3,
        'Name': u'Maestro'

    },
    {
        'id': 4,
        'Name': u'BlueVisa'
    }
]

terminals = [
    {
        'id': 1,
        'Device_id': u'T1'
    },
    {
        'id': 2,
        'Device_id': u'T2'
    }
]

channels = [
    {
        'id': 1,
        'cardId': u'1',
        'terminalId': u'2'
    },
    {
        'id': 2,
        'cardId': u'2',
        'terminalId': u'1'
    }
]

# GET cards
def make_public_card(card):
    new_card = {}
    for field in card:
        if field == 'id':
            new_card['uri'] = url_for('get_cards', card_id = card['id'], _external = True)
        else:
            new_card[field] = card[field]
    return new_card
    
@app.route('/todo/api/v1.0/cards', methods = ['GET'])
@auth.login_required
def get_cards():
    return jsonify( { 'cards': list(map(make_public_card, cards)) } )

@app.route('/todo/api/v1.0/cards/<int:card_id>', methods = ['GET'])
@auth.login_required
def get_card(card_id):
    card = list(filter(lambda t: t['id'] == card_id, cards))
    if len(card) == 0:
        abort(404)
    return jsonify( { 'card': make_public_card(card[0]) } )

# GET terminals

def make_public_terminal(terminal):
    new_terminal = {}
    for field in terminal:
        if field == 'id':
            new_terminal['uri'] = url_for('get_terminals', terminal_id = terminal['id'], _external = True)
        else:
            new_terminal[field] = terminal[field]
    return new_terminal
    
@app.route('/todo/api/v1.0/terminals', methods = ['GET'])
@auth.login_required
def get_terminals():
    return jsonify( { 'terminals': list(map(make_public_terminal, terminals)) } )

@app.route('/todo/api/v1.0/terminals/<int:terminal_id>', methods = ['GET'])
@auth.login_required
def get_terminal(terminal_id):
    terminal = list(filter(lambda t: t['id'] == terminal_id, terminals))
    if len(terminal) == 0:
        abort(404)
    return jsonify( { 'terminal': make_public_terminal(terminal[0]) } )

# GET channels

def make_public_channel(channel):
    new_channel = {}
    for field in channel:
        if field == 'id':
            new_channel['uri'] = url_for('get_channels', channel_id = channel['id'], _external = True)
        else:
            new_channel[field] = channel[field]
    return new_channel
    
@app.route('/todo/api/v1.0/channels', methods = ['GET'])
@auth.login_required
def get_channels():
    return jsonify( { 'channels': list(map(make_public_channel, channels)) } )

@app.route('/todo/api/v1.0/channels/<int:channel_id>', methods = ['GET'])
@auth.login_required
def get_channel(channel_id):
    channel = list(filter(lambda t: t['id'] == channel_id, channels))
    if len(channel) == 0:
        abort(404)
    return jsonify( { 'channel': make_public_channel(channel[0]) } )
    
#POST card

@app.route('/todo/api/v1.0/cards', methods = ['POST'])
@auth.login_required
def create_card():
    if not request.json or not 'Name' in request.json:
        abort(400)
    card = {
        'id': cards[-1]['id'] + 1,
        'Name': request.json['Name']
    }
    cards.append(card)
    return jsonify( { 'card': make_public_card(card) } ), 201

#POST terminal

@app.route('/todo/api/v1.0/terminals', methods = ['POST'])
@auth.login_required
def create_terminal():
    if not request.json or not 'Device_id' in request.json:
        abort(400)
    terminal = {
        'id': cards[-1]['id'] + 1,
        'Device_id': request.json['Device_id']
    }
    terminals.append(terminal)
    return jsonify( { 'terminal': make_public_terminal(terminal) } ), 201

#POST channel

@app.route('/todo/api/v1.0/channels', methods = ['POST'])
@auth.login_required
def create_channel():
    if not request.json or not 'cardId' in request.json:
        abort(400)
    channel = {
        'id': channels[-1]['id'] + 1,
        'cardId': request.json['cardId'],
        'terminalId': request.json['terminalId']
    }
    channels.append(channel)
    return jsonify( { 'channel': make_public_channel(channel) } ), 201

#PUT card   

@app.route('/todo/api/v1.0/cards/<int:card_id>', methods = ['PUT'])
@auth.login_required
def update_card(card_id):
    card = list(filter(lambda t: t['id'] == card_id, cards))
    if len(card) == 0:
        abort(404)
    if not request.json:
        abort(400)
    if 'Name' in request.json and type(request.json['Name']) != str:
        abort(400)
   
    card[0]['Name'] = request.json.get('Name', card[0]['Name'])
    return jsonify( { 'card': make_public_card(card[0]) } )

#PUT terminal  

@app.route('/todo/api/v1.0/terminals/<int:terminal_id>', methods = ['PUT'])
@auth.login_required
def update_terminal(terminal_id):
    terminal = list(filter(lambda t: t['id'] == terminal_id, terminals))
    if len(terminal) == 0:
        abort(404)
    if not request.json:
        abort(400)
    if 'Device_id' in request.json and type(request.json['Device_id']) != str:
        abort(400)
   
    terminal[0]['Device_id'] = request.json.get('Device_id', terminal[0]['Device_id'])
    return jsonify( { 'terminal': make_public_terminal(terminal[0]) } )
    
#PUT channel  

@app.route('/todo/api/v1.0/channels/<int:channel_id>', methods = ['PUT'])
@auth.login_required
def update_channel (channel_id):
    channel  = list(filter(lambda t: t['id'] == channel_id, channels))
    if len(channel ) == 0:
        abort(404)
    if not request.json:
        abort(400)
    if 'cardId' in request.json and type(request.json['cardId']) != unicode:
        abort(400)
    if 'terminalId' in request.json and type(request.json['terminalId']) != unicode:
        abort(400)
    
    channel[0]['cardId'] = request.json.get('cardId', channel[0]['cardId'])
    channel[0]['terminalId'] = request.json.get('terminalId', channel[0]['terminalId'])

    return jsonify( { 'channel': make_public_channel(channel[0]) } )

#DELETE card
@app.route('/todo/api/v1.0/cards/<int:card_id>', methods = ['DELETE'])
@auth.login_required
def delete_card(card_id):
    card = list(filter(lambda t: t['id'] == card_id, cards))
    if len(card) == 0:
        abort(404)
    cards.remove(card[0])
    return jsonify( { 'result': True } )
    

#DELETE terminal
@app.route('/todo/api/v1.0/terminals/<int:terminal_id>', methods = ['DELETE'])
@auth.login_required
def delete_terminal(terminal_id):
    terminal = list(filter(lambda t: t['id'] == terminal_id, terminals))
    if len(terminal) == 0:
        abort(404)
    terminals.remove(terminal[0])
    return jsonify( { 'result': True } )
    
    
#DELETE channel
@app.route('/todo/api/v1.0/channels/<int:channel_id>', methods = ['DELETE'])
@auth.login_required
def delete_channel(channel_id):
    channel = list(filter(lambda t: t['id'] == channel_id, channels))
    if len(channel) == 0:
        abort(404)
    channels.remove(channel[0])
    return jsonify( { 'result': True } )
    
if __name__ == '__main__':
    app.run(debug = True)
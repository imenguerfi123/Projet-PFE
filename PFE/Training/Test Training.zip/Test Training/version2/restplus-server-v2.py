from flask import Flask,  request
from flask_restplus import Api, Resource, fields
from werkzeug.contrib.fixers import ProxyFix
from functools import wraps 
from flask_serial import Serial
import time

app = Flask(__name__)

app.config['SERIAL_TIMEOUT'] = 0.1
app.config['SERIAL_PORT'] = '/dev/ttyS0'
app.config['SERIAL_BAUDRATE'] = 9600
app.config['SERIAL_BYTESIZE'] = 8
app.config['SERIAL_PARITY'] = 'N'
app.config['SERIAL_STOPBITS'] = 1

ser =Serial(app)
app.wsgi_app = ProxyFix(app.wsgi_app)

authorizations = {
    'apikey' : {
        'type' : 'apiKey',
        'in' : 'header',
        'name' : 'X-API-KEY'
    }
}


api = Api(app, authorizations=authorizations, version='1.0', title='Multiplexing API',
    description='A simple Multiplexing API',
)

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):

        token = None

        if 'X-API-KEY' in request.headers:
            token = request.headers['X-API-KEY']

        if not token:
            return {'message' : 'Token is missing.'}, 401

        if token != 'mytoken':
            return {'message' : 'Your token is wrong, wrong, wrong!!!'}, 401

        print('TOKEN: {}'.format(token))
        return f(*args, **kwargs)

    return decorated


ns_card = api.namespace('Cards', description='Cards operations')
ns_terminal = api.namespace('Terminals', description='Terminals operations')
ns_channel = api.namespace('Channels', description='Channels operations')

card = api.model('cards', {
    'slot_id': fields.Integer(readonly=True, description='The card unique identifier'),
    'name': fields.String(required=True, description='The card details')
})

terminal = api.model('terminals', {
    'probe_id': fields.Integer(readonly=True, description='The card unique identifier'),
    'device_id': fields.String(required=True, description='The card details')
})

channel = api.model('channels', {
    'channel_id': fields.Integer(readonly=True, description='The channel unique identifier'),
    'slot_id': fields.String(required=True, description='The channel details'),
    'probe_id': fields.String(required=True, description='The channel details')
})


#Cards
class CardDAO(object):
    def __init__(self):
        self.counter = 0
        self.cards = []
        self.nbr_slots_max= 4
        
    def get_card_by_id(self, slot_id):
        ''' Fetch card
            :return card given its identifier
            id: integer
            Name: str
        ''' 
        for card in self.cards:
            if card['id'] == slot_id:
                return card
        api.abort(404, "card {} doesn't exist".format(slot_id))

    def create_card(self, data):
        ''' create a new card
            dictionary(e.g:{"Name":"Visa"}
        '''
        if self.counter < self.nbr_slots_max :
            card = data
            self.cards.append(card)
            card['id'] = self.counter = self.counter + 1
            return card
        api.abort(500, "The maximum number of slots has been exceeded .")

    def update_card(self, slot_id, data):
        ''' Update a card given its identifier "id" 
        ''' 
        card = self.get_card_by_id(slot_id)
        card.update(data)
        return card

    def delete_card(self, slot_id):
        ''' Delete a card given its identifier
        '''
        card = self.get_card_by_id(slot_id)
        self.cards.remove(card)

DAO = CardDAO()
DAO.create_card({'name': 'Visa'})


@ns_card.route('/')
class CardList(Resource):

    @ser.on_message()
    def handle_message(msg):
        print("receive a message:", str(msg))
        if(msg==b"error"):
            print ("no card exists")
        elif (msg==b"0x00026000"):
            ser.on_send("okok")
        elif (msg==b'True'):
            DAO.create_card({'Name':'smart'})
            print ("a new card has been added")
        elif(msg==b'ok'):
            # send a msg of str
            cmd=input("Enter command : ")
            ser.on_send(cmd)
        else:
            pass

    @ser.on_log()
    def handle_logging(level, info):
        print(level, info)

    ''' Shows a list of all cards, and lets you POST to add new cards
    '''
    @api.doc(security='apikey')
    @token_required
    @ns_card.doc('list_cards')
    @ns_card.marshal_list_with(card, envelope='cards')
    def get(self):
        ''' List all cards
        '''
        return DAO.cards
    @api.doc(security='apikey')
    @token_required
    @ns_card.doc('create_card')
    @ns_card.expect(card)
    @ns_card.marshal_with(card, code=201)
    def post(self):
        ''' Create a new card
        '''
        return DAO.create_card(api.payload), 201


@ns_card.route('/<int:slot_id>')
@ns_card.response(404, 'Card not found')
@ns_card.param('slot_id', 'The card identifier')
class Card(Resource):
    ''' Show a single card item and lets you delete them
    '''
    @api.doc(security='apikey')
    @token_required
    @ns_card.doc('get_card')
    @ns_card.marshal_with(card)
    def get(self, slot_id):
        ''' Fetch a given resource
        '''
        return DAO.get_card_by_id(slot_id)
    @api.doc(security='apikey')
    @token_required
    @ns_card.doc('delete_card')
    @ns_card.response(204, 'Card deleted')
    def delete(self, slot_id):
        ''' Delete a card given its identifier
        '''
        DAO.delete_card(slot_id)
        return '', 204
    @api.doc(security='apikey')
    @token_required
    @ns_card.expect(card)
    @ns_card.marshal_with(card)
    def put(self, slot_id):
        ''' Update a card given its identifier
        '''
        return DAO.update_card(slot_id, api.payload)
        

#Terminals
class TerminalDAO(object):
    def __init__(self):
        self.counter = 0
        self.terminals = []
        self.nbr_Probes_max= 2

    def get_terminal_by_id(self, probe_id):
        ''' Fetch terminal
            :return terminal
            id: integer
            Device_id: str
        ''' 
        for terminal in self.terminals:
            if terminal['id'] == probe_id:
                return terminal
        api.abort(404, "terminal {} doesn't exist".format(probe_id))

    def create_terminal(self, data):
        ''' create a new terminal
            dictionary(e.g:{"Device_id":"1"}
        ''' 
        if self.counter < self.nbr_Probes_max :
            terminal = data
            self.terminals.append(terminal)
            terminal['id'] = self.counter = self.counter + 1
            return terminal
        api.abort(500, "The maximum number of probes has been exceeded .")

    def update_terminal(self, probe_id, data):
        ''' Update a terminal given its identifier "probe_id" 
        ''' 
        terminal = self.get_terminal_by_id(probe_id)
        terminal.update(data)
        return terminal

    def delete_terminal(self, probe_id):
        ''' Delete a terminal given its identifier "probe_id" 
        '''
        terminal = self.get_terminal_by_id(probe_id)
        self.terminals.remove(terminal)


DAOT = TerminalDAO()
DAOT.create_terminal({'device_id': '1'})



@ns_terminal.route('/')
class TerminalList(Resource):

    @ser.on_message()
    def handle_message(msg):
        print("receive a message:", str(msg))
        if (msg==b'tTrue'):
            DAOT.create_terminal({'device_id': '1'})
            print("a new terminal has been added")
        elif (msg==b'False'):
            print ("the terminal is already busy")
        else:
            pass

    @ser.on_log()
    def handle_logging(level, info):
        print(level, info)
    ''' Shows a list of all terminals, and lets you POST to add new terminals
    '''
    @api.doc(security='apikey')
    @token_required
    @ns_terminal.doc('list_terminals')
    @ns_terminal.marshal_list_with(terminal, envelope='terminals')
    def get(self):
        ''' List all terminals
        '''
        return DAOT.terminals
     
    @api.doc(security='apikey')
    @token_required
    @ns_terminal.doc('create_terminal')
    @ns_terminal.expect(terminal)
    @ns_terminal.marshal_with(terminal, code=201)
    def post(self):
        ''' Create a new terminal
        '''
        return DAOT.create_terminal(api.payload), 201


@ns_terminal.route('/<int:probe_id>')
@ns_terminal.response(404, 'Terminal not found')
@ns_terminal.param('probe_id', 'The terminal identifier')
class Terminal(Resource):
    ''' Show a single terminal item and lets you delete them
    '''
    @api.doc(security='apikey')
    @token_required
    @ns_terminal.doc('get_terminal')
    @ns_terminal.marshal_with(terminal)
    def get(self, probe_id):
        ''' Fetch a given resource
        '''
        return DAOT.get_terminal_by_id(probe_id)
     
    @api.doc(security='apikey')
    @token_required
    @ns_terminal.doc('delete_terminal')
    @ns_terminal.response(204, 'Terminal deleted')
    def delete(self, probe_id):
        ''' Delete a terminal given its identifier
        '''
        DAOT.delete_terminal(probe_id)
        return '', 204
    
    @api.doc(security='apikey')
    @token_required
    @ns_terminal.expect(terminal)
    @ns_terminal.marshal_with(terminal)
    def put(self, probe_id):
        ''' Update a card given its identifier
        '''
        return DAOT.update_terminal(probe_id, api.payload)


#Channels
class ChannelDAO(object):
    def __init__(self):
        self.counter = 0
        self.channels = []
        self.nbr_Probes_max= 2

    def get_channel_by_id(self, channel_id):   
        ''' Fetch channel
            :return a channel given its identifier
            id: integer
            Card_id: string
            Terminal_id: string
        '''
        for channel in self.channels:
            if channel['id'] == channel_id:
                return channel
        api.abort(404, "channel {} doesn't exist".format(channel_id))

    def create_channel(self, data):
        '''create a new channel 
         dictionary(e.g:{"Card_id":"1", "Terminal_id":"3"}
        ''' 
        if self.counter < self.nbr_Probes_max :
            channel = data
            self.channels.append(channel)
            channel['id'] = self.counter = self.counter + 1
            return channel
        if self.counter == self.nbr_Probes_max :
            api.abort(500, "The number of channels is exactly equal to the numbers of the probes.")

    def update_channel(self, channel_id, data):
        ''' Update a channel given its identifier "channel_id" 
        '''
        channel = self.get_channel_by_id(channel_id)
        channel.update(data)
        return channel

    def delete_channel(self, channel_id):
        ''' Delete a channel given its identifier "channel_id" 
        '''
        channel = self.get_channel_by_id(channel_id)
        self.channels.remove(channel)


DAOC = ChannelDAO()
DAOC.create_channel({'slot_id': '1', 'probe_id': '2' })


@ns_channel.route('/')
class ChannelList(Resource):

    @ser.on_message()
    def handle_message(msg):
        print("receive a message:", str(msg))
        if (msg==b'ch'):
            DAOC.create_channel({'Card_id': '1', 'Terminal_id': '1' })
            print ("a new channel has been added")
        else:
            pass

    @ser.on_log()
    def handle_logging(level, info):
        print(level, info)

    ''' Shows a list of all channels, and lets you POST to add new channels
    '''
    @api.doc(security='apikey')
    @token_required
    @ns_channel.doc('list_channels')
    @ns_channel.marshal_list_with(channel, envelope='channels')
    def get(self):
        ''' List all channels
        '''
        return DAOC.channels
     
    @api.doc(security='apikey')
    @token_required
    @ns_channel.doc('create_channel')
    @ns_channel.expect(channel)
    @ns_channel.marshal_with(channel, code=201)
    def post(self):
        ''' Create a new channel
        '''
        return DAOC.create_channel(api.payload), 201


@ns_channel.route('/<int:channel_id>')
@ns_channel.response(404, 'Channel not found')
@ns_channel.param('channel_id', 'The channel identifier')
class Channel(Resource):
    ''' Show a single channel item and lets you delete them
    '''
    @api.doc(security='apikey')
    @token_required
    @ns_channel.doc('get_channel')
    @ns_channel.marshal_with(channel)
    def get(self, channel_id):
        ''' Fetch a given resource
        '''
        return DAOC.get_channel_by_id(channel_id)
     
    @api.doc(security='apikey')
    @token_required
    @ns_channel.doc('delete_channel')
    @ns_channel.response(204, 'Channel deleted')
    def delete(self, channel_id):
        ''' Delete a channel given its identifier
        '''
        DAOC.delete_channel(channel_id)
        return '', 204
     
    @api.doc(security='apikey')
    @token_required
    @ns_channel.expect(channel)
    @ns_channel.marshal_with(channel)
    def put(self, channel_id):
        ''' Update a channel given its identifier
        '''
        return DAOC.update_channel(channel_id, api.payload)

if __name__ == '__main__':
    app.run(debug=True)
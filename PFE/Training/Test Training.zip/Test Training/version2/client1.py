import requests
import json

class Card():
    def __init__(self):
        self.url = 'http://192.168.8.100:5000'
        self.headers = {'Content-Type': 'application/json' , 'X-API-KEY': 'mytoken'}

    def get(self):
        response = requests.get(
            "{}{}".format(self.url, '/Cards'),
            headers=self.headers
        )
        print(response.status_code)
        print(response.headers)
        print (response.content)
    
    def post_card(self, new_card_data):
        response = requests.post(
            "{}{}".format(self.url, '/Cards/'),
            headers=self.headers,
            data=json.dumps(new_card_data) 
        )
        print(response.status_code)
        print(response.headers)
        print (response.content)
    
    def get_card(self, card_id):
        response = requests.get(
            "{}{}{}".format(self.url, '/Cards/', card_id),
            headers=self.headers
        )
        print(response.status_code)
        print(response.headers)
        print (response.content)
        
    def update_card(self, card_id, new_card_data):
        response = requests.put(
            "{}{}{}".format(self.url, '/Cards/', card_id),
            headers=self.headers,
            data=json.dumps(new_card_data)             
        )
        print(response.status_code)
        print(response.headers)
        print (response.content)
        
    def delete_card(self, card_id):
        response = requests.delete(
            "{}{}{}".format(self.url, '/Cards/', card_id),
            headers=self.headers
        )
        print(response.status_code)
        print(response.headers)
        print (response.content)
        
        
#terminal
class Terminal():
    def __init__(self):
        self.url = 'http://192.168.8.100:5000'
        self.headers = {'Content-Type': 'application/json' , 'X-API-KEY': 'mytoken'}

    def get(self):
        response = requests.get(
            "{}{}".format(self.url, '/Terminals'),
            headers=self.headers
        )
        print(response.status_code)
        print(response.headers)
        print(response.content)
        
    def post_terminal(self, new_terminal_data):
        response = requests.post(
            "{}{}".format(self.url, '/Terminals/'),
            headers=self.headers,
            data=json.dumps(new_terminal_data) 
        )
        print(response.status_code)
        print(response.headers)
        print (response.content)
    
    def get_terminal(self, terminal_id):
        response = requests.get(
            "{}{}{}".format(self.url, '/Terminals/', terminal_id),
            headers=self.headers
        )
        print(response.status_code)
        print(response.headers)
        print (response.content)
        
    def update_terminal(self, terminal_id, new_terminal_data):
        response = requests.put(
            "{}{}{}".format(self.url, '/Terminals/', terminal_id),
            headers=self.headers,
            data=json.dumps(new_terminal_data)             
        )
        print(response.status_code)
        print(response.headers)
        print(response.content)
        
    def delete_terminal(self, terminal_id):
        response = requests.delete(
            "{}{}{}".format(self.url, '/Terminals/', terminal_id),
            headers=self.headers
        )
        print(response.status_code)
        print(response.headers)
        print (response.content)

#channel
class Channel():
    def __init__(self):
        self.url = 'http://192.168.8.100:5000'
        self.headers = {'Content-Type': 'application/json' , 'X-API-KEY': 'mytoken'}

    def get(self):
        response = requests.get(
            "{}{}".format(self.url, '/Channels'),
            headers=self.headers
        )
        print(response.status_code)
        print(response.headers)
        print(response.content)
        
    def post_channel(self, new_channel_data):
        response = requests.post(
            "{}{}".format(self.url, '/Channels/'),
            headers=self.headers,
            data=json.dumps(new_channel_data) 
        )
        print(response.status_code)
        print(response.headers)
        print (response.content)

        
    def get_channel(self, channel_id):
        response = requests.get(
            "{}{}{}".format(self.url, '/Channels/', channel_id),
            headers=self.headers
        )
        print(response.status_code)
        print(response.headers)
        print (response.content)
        
    def update_channel(self, channel_id, new_channel_data):
        response = requests.put(
            "{}{}{}".format(self.url, '/Channels/', channel_id),
            headers=self.headers,
            data=json.dumps(new_channel_data)             
        )
        print(response.status_code)
        print(response.headers)
        print(response.content)
        
    def delete_channel(self, channel_id):
        response = requests.delete(
            "{}{}{}".format(self.url, '/Channels/', channel_id),
            headers=self.headers
        )
        print(response.status_code)
        print(response.headers)
        print (response.content)

if __name__ == "__main__":
    cad= Card()
    cad.get()
    cad.post_card({"id":5, "Name":"ppp"})
    cad.get_card(1)
    cad.update_card( 1, {"Name":"aaaa"})
    cad.delete_card(1)
    ter=Terminal()
    ter.get()
    ter.post_terminal({"id":3, "Device_id":"1"})
    ter.get_terminal(1)
    ter.update_terminal(1, {"Device_id":"2"})
    ter.delete_terminal(1)
    cha=Channel()
    cha.get()
    cha. post_channel({"id":5, "Card_id":"1", "Terminal_id":"3"})
    cha.get_channel(1)
    cha.update_channel(1, {"Card_id":"2", "Terminal_id":"2"} )
    cha.delete_channel(1)

import requests

class Pet():
    def __init__(self, user, password, url):
        self.auth = requests.auth.HTTPBasicAuth(user, password)
        self.user = user
        self.password = password
        self.url = url
        self.headers = {'Content-Type': 'application/json'}

    def get_pets(self):
        response = requests.get(
            "{}{}".format(self.url, '/pets'),
            auth=self.auth,
            headers=self.headers
        )
        if response.status_code == 200:
            return json.loads(response.text)
        else:
            raise PetException(response.status_code, json.loads(response.text)['message'])      

    def get_pet(self, pet_id):
        response = requests.get(
            "{}{}{}".format(self.url, '/pets/', pet_id),
            auth=self.auth,
            headers=self.headers
        )
        if response.status_code == 200:
            return json.loads(response.text)
        else:
            raise PetException(response.status_code, json.loads(response.text)['message'])        

    def update_pet(self, pet_id, new_pet_data):
        response = requests.put(
            "{}{}{}".format(self.url, '/pets/', pet_id),
            auth=self.auth,
            headers=self.headers,
            data=json.dumps(new_pet_data)           
        )
        if response.status_code == 200:
            return json.loads(response.text)
        else:
            raise PetException(response.status_code, json.loads(response.text)['message'])  

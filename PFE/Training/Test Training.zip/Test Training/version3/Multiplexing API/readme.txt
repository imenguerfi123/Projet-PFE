

**************************************Server creation Steps******************************


1) create  directories

            mkdir Multiplexing-API

            cd  Multiplexing-API

            mkdir environment  models  resources  server
             
    
2) Create an environment

            sudo apt install python3-pip

            sudo apt install python3-venv 
             
            sudo python3 -m venv env

3) Change the permission of virtuel environment 

            sudo chown -R pi:pi env

4) Activate the environment

             . env/bin/activate

5) Install all dependencies
             
             pip install Flask

             pip install flask-restplus

6) Create the code structure

            nano main.py
           
            nano  environment/ instance.py
 
            nano  server/ instance.py
            
            nano models/card.py 

            nano models/terminal.py 

            nano models/channel.py

            nano resources/card.py

            nano resources/terminal.py 

            nano resources/channel.py
           
7) Execute the application

            export FLASK_APP=main.py

            export FLASK_ENV=development

            flask run --host=0.0.0.0 
from flask import Flask,  request
from flask_restplus import Api, Resource, fields

from server.instance import server
from models.channel import channel
from werkzeug.contrib.fixers import ProxyFix
from functools import wraps 

app, api = server.app, server.api

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):

        token = None

        if 'X-API-KEY' in request.headers:
            token = request.headers['X-API-KEY']

        if not token:
            return {'message' : 'Token is missing.'}, 401

        if token != 'mytoken':
            return {'message' : 'Your token is wrong, wrong, wrong!!!'}, 401

        print('TOKEN: {}'.format(token))
        return f(*args, **kwargs)

    return decorated

ns_channel = server.api.namespace('Channels', description='Channels operations')

#Channels
class ChannelDAO(object):
    def __init__(self):
        self.counter = 0
        self.channels = []
        '''nbr_Probes_max: The maximum number of probes'''
        self.nbr_Probes_max= 2

    '''Show a single channel item '''
    def get(self, id):
        for channel in self.channels:
            if channel['id'] == id:
                return channel
        api.abort(404, "channel {} doesn't exist".format(id))
     
    '''create a new channel'''
    def create(self, data):
        if self.counter < self.nbr_Probes_max :
            channel = data
            self.channels.append(channel)
            channel['id'] = self.counter = self.counter + 1
            return channel
        if self.counter == self.nbr_Probes_max :
            api.abort(500, "The number of channels is exactly equal to the numbers of the probes.")

    '''Update a channel given its identifier "id" '''
    def update(self, id, data):
        channel = self.get(id)
        channel.update(data)
        return channel
    
    '''Delete a channel given its identifier "id" '''
    def delete(self, id):
        channel = self.get(id)
        self.channels.remove(channel)

'''create an instance of the class "ChannelDAO"
 that we will use in the two classes "ChannelList" and "Channel" later '''
DAOC = ChannelDAO()

'''create a channel using the "create" function of the class "ChannelDAO"'''
DAOC.create({'Card_id': '1', 'Terminal_id': '2' })



@ns_channel.route('/')
class ChannelList(Resource):
    '''Shows a list of all channels, and lets you POST to add new channels'''
    @api.doc(security='apikey')
    @token_required
    @ns_channel.doc('list_channels')
    @ns_channel.marshal_list_with(channel, envelope='channels')
    def get(self):
        '''List all channels'''
        return DAOC.channels
     
    @api.doc(security='apikey')
    @token_required
    @ns_channel.doc('create_channel')
    @ns_channel.expect(channel)
    @ns_channel.marshal_with(channel, code=201)
    def post(self):
        '''Create a new channel'''
        return DAOC.create(api.payload), 201


@ns_channel.route('/<int:id>')
@ns_channel.response(404, 'Channel not found')
@ns_channel.param('id', 'The channel identifier')
class Channel(Resource):
    '''Show a single channel item and lets you delete them'''
    @api.doc(security='apikey')
    @token_required
    @ns_channel.doc('get_channel')
    @ns_channel.marshal_with(channel)
    def get(self, id):
        '''Fetch a given resource'''
        return DAOC.get(id)
     
    @api.doc(security='apikey')
    @token_required
    @ns_channel.doc('delete_channel')
    @ns_channel.response(204, 'Channel deleted')
    def delete(self, id):
        '''Delete a channel given its identifier'''
        DAOC.delete(id)
        return '', 204
     
    @api.doc(security='apikey')
    @token_required
    @ns_channel.expect(channel)
    @ns_channel.marshal_with(channel)
    def put(self, id):
        '''Update a channel given its identifier'''
        return DAOC.update(id, api.payload)
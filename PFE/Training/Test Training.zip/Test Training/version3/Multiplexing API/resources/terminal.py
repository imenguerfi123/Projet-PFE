from flask import Flask,  request
from flask_restplus import Api, Resource, fields

from server.instance import server
from models.terminal import terminal
from werkzeug.contrib.fixers import ProxyFix
from functools import wraps 

app, api = server.app, server.api

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):

        token = None

        if 'X-API-KEY' in request.headers:
            token = request.headers['X-API-KEY']

        if not token:
            return {'message' : 'Token is missing.'}, 401

        if token != 'mytoken':
            return {'message' : 'Your token is wrong, wrong, wrong!!!'}, 401

        print('TOKEN: {}'.format(token))
        return f(*args, **kwargs)

    return decorated


ns_terminal = server.api.namespace('Terminals', description='Terminals operations')


class TerminalDAO(object):
    def __init__(self):
        self.counter = 0
        self.terminals = []
        '''nbr_Probes_max: The maximum number of probes'''
        self.nbr_Probes_max= 2

    '''Show a single terminal item '''
    def get(self, id):
        for terminal in self.terminals:
            if terminal['id'] == id:
                return terminal
        api.abort(404, "terminal {} doesn't exist".format(id))
    
    '''create a new terminal'''
    def create(self, data):
        if self.counter < self.nbr_Probes_max :
            terminal = data
            self.terminals.append(terminal)
            terminal['id'] = self.counter = self.counter + 1
            return terminal
        api.abort(500, "The maximum number of probes has been exceeded .")
    
    '''Update a terminal given its identifier "id" '''
    def update(self, id, data):
        terminal = self.get(id)
        terminal.update(data)
        return terminal
    '''Delete a terminal given its identifier "id" '''
    def delete(self, id):
        terminal = self.get(id)
        self.terminals.remove(terminal)

'''create an instance of the class "TerminalDAO"
 that we will use in the two classes "TerminalList" and "Terminal" later '''
DAOT = TerminalDAO()

'''create a terminal using the "create" function of the class "TerminalDAO"'''
DAOT.create({'Device_id': '1'})


@ns_terminal.route('/')
class TerminalList(Resource):
    '''Shows a list of all terminals, and lets you POST to add new terminals'''
    @api.doc(security='apikey')
    @token_required
    @ns_terminal.doc('list_terminals')
    @ns_terminal.marshal_list_with(terminal, envelope='terminals')
    def get(self):
        '''List all terminals'''
        return DAOT.terminals
     
    @api.doc(security='apikey')
    @token_required
    @ns_terminal.doc('create_terminal')
    @ns_terminal.expect(terminal)
    @ns_terminal.marshal_with(terminal, code=201)
    def post(self):
        '''Create a new terminal'''
        return DAOT.create(api.payload), 201


@ns_terminal.route('/<int:id>')
@ns_terminal.response(404, 'Terminal not found')
@ns_terminal.param('id', 'The terminal identifier')
class Terminal(Resource):
    '''Show a single terminal item and lets you delete them'''
    @api.doc(security='apikey')
    @token_required
    @ns_terminal.doc('get_terminal')
    @ns_terminal.marshal_with(terminal)
    def get(self, id):
        '''Fetch a given resource'''
        return DAOT.get(id)
     
    @api.doc(security='apikey')
    @token_required
    @ns_terminal.doc('delete_terminal')
    @ns_terminal.response(204, 'Terminal deleted')
    def delete(self, id):
        '''Delete a terminal given its identifier'''
        DAOT.delete(id)
        return '', 204
    
    @api.doc(security='apikey')
    @token_required
    @ns_terminal.expect(terminal)
    @ns_terminal.marshal_with(terminal)
    def put(self, id):
        '''Update a terminal given its identifier'''
        return DAOT.update(id, api.payload)


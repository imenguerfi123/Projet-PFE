from flask import Flask,  request
from flask_restplus import Api, Resource, fields
from werkzeug.contrib.fixers import ProxyFix
from functools import wraps 
from server.instance import server
from models.card import card

app, api = server.app, server.api

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):

        token = None

        if 'X-API-KEY' in request.headers:
            token = request.headers['X-API-KEY']

        if not token:
            return {'message' : 'Token is missing.'}, 401

        if token != 'mytoken':
            return {'message' : 'Your token is wrong, wrong, wrong!!!'}, 401

        print('TOKEN: {}'.format(token))
        return f(*args, **kwargs)

    return decorated

ns_card = server.api.namespace('Cards', description='Cards operations')

#Cards
class CardDAO(object):
    def __init__(self):
        self.counter = 0
        self.cards = []
        '''nbr_slots_max: The maximum number of slots'''
        self.nbr_slots_max= 4
    
    '''Show a single card item '''    
    def get(self, id):
        for card in self.cards:
            if card['id'] == id:
                return card
        api.abort(404, "card {} doesn't exist".format(id))

    '''create a new card'''
    def create(self, data):
        if self.counter < self.nbr_slots_max :
            card = data
            self.cards.append(card)
            card['id'] = self.counter = self.counter + 1
            return card
        api.abort(500, "The maximum number of slots has been exceeded .")

    '''Update a card given its identifier "id" '''
    def update(self, id, data):
        card = self.get(id)
        card.update(data)
        return card

    '''Delete a card given its identifier "id" '''
    def delete(self, id):
        card = self.get(id)
        self.cards.remove(card)

'''create an instance of the class "CardDAO"
 that we will use in the two classes "CardList" and "Card" later '''
DAO = CardDAO()

'''create a card using the "create" function of the class "CardDAO"'''
DAO.create({'Name': 'Visa'})


@ns_card.route('/')
class CardList(Resource):
    '''Shows a list of all cards, and lets you POST to add new cards'''
    @api.doc(security='apikey')
    @token_required
    @ns_card.doc('list_cards')
    @ns_card.marshal_list_with(card, envelope='cards')
    def get(self):
        '''List all cards'''
        return DAO.cards
    @api.doc(security='apikey')
    @token_required
    @ns_card.doc('create_card')
    @ns_card.expect(card)
    @ns_card.marshal_with(card, code=201)
    def post(self):
        '''Create a new card'''
        return DAO.create(api.payload), 201


@ns_card.route('/<int:id>')
@ns_card.response(404, 'Card not found')
@ns_card.param('id', 'The card identifier')
class Card(Resource):
    '''Show a single card item and lets you delete them'''
    @api.doc(security='apikey')
    @token_required
    @ns_card.doc('get_card')
    @ns_card.marshal_with(card)
    def get(self, id):
        '''Fetch a given resource'''
        return DAO.get(id)
    @api.doc(security='apikey')
    @token_required
    @ns_card.doc('delete_card')
    @ns_card.response(204, 'Card deleted')
    def delete(self, id):
        '''Delete a card given its identifier'''
        DAO.delete(id)
        return '', 204
    @api.doc(security='apikey')
    @token_required
    @ns_card.expect(card)
    @ns_card.marshal_with(card)
    def put(self, id):
        '''Update a card given its identifier'''
        return DAO.update(id, api.payload)
        
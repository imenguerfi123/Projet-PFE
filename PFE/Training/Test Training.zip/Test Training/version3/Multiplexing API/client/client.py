import requests
import json

#Cards
class Card():
    def __init__(self):
        self.url = 'http://192.168.8.100:5000'
        self.headers = {'Content-Type': 'application/json' , 'X-API-KEY': 'mytoken'}
        self.counter = 0
        self.nbr_slots_max= 4
    
    '''List all cards'''   
    def get(self):
        response = requests.get(
            "{}{}".format(self.url, '/Cards'),
            headers=self.headers
        )
        print(response.status_code)
        print(response.headers)
        print (response.content)
    '''create a new card'''
    def post_card(self, new_card_data):
        if self.counter < self.nbr_slots_max :
            response = requests.post(
                "{}{}".format(self.url, '/Cards/'),
                headers=self.headers,
                data=json.dumps(new_card_data) 
            )
            new_card_data['id'] = self.counter = self.counter + 1
            print(response.status_code)
            print(response.headers)
            print(response.content)
    '''Show a single card item '''  
    def get_card(self, card_id):
        response = requests.get(
            "{}{}{}".format(self.url, '/Cards/', card_id),
            headers=self.headers
        )
        print(response.status_code)
        print(response.headers)
        print(response.content)
    '''Update a card given its identifier "id" '''    
    def update_card(self, card_id, new_card_data):
        response = requests.put(
            "{}{}{}".format(self.url, '/Cards/', card_id),
            headers=self.headers,
            data=json.dumps(new_card_data)             
        )
        print(response.status_code)
        print(response.headers)
        print(response.content)
    '''Delete a card given its identifier "id" '''    
    def delete_card(self, card_id):
        response = requests.delete(
            "{}{}{}".format(self.url, '/Cards/', card_id),
            headers=self.headers
        )
        print(response.status_code)
        print(response.headers)
        print(response.content)
        
        
#Terminals 
class Terminal():
    def __init__(self):
        self.url = 'http://192.168.8.100:5000'
        self.headers = {'Content-Type': 'application/json' , 'X-API-KEY': 'mytoken'}
        self.counter = 0
        self.nbr_Probes_max= 2
    
    '''List all terminals'''    
    def get(self):
        response = requests.get(
            "{}{}".format(self.url, '/Terminals'),
            headers=self.headers
        )
        print(response.status_code)
        print(response.headers)
        print(response.content)
    
    '''create a new terminal '''   
    def post_terminal(self, new_terminal_data):
        if self.counter < self.nbr_Probes_max :
            response = requests.post(
                "{}{}".format(self.url, '/Terminals/'),
                headers=self.headers,
                data=json.dumps(new_terminal_data) 
            )
            new_terminal_data['id'] = self.counter = self.counter + 1
            print(response.status_code)
            print(response.headers)
            print(response.content)
    
    '''Show a single terminal item '''  
    def get_terminal(self, terminal_id):
        response = requests.get(
            "{}{}{}".format(self.url, '/Terminals/', terminal_id),
            headers=self.headers
        )
        print(response.status_code)
        print(response.headers)
        print(response.content)
    
    '''Update a terminal given its identifier "id" '''    
    def update_terminal(self, terminal_id, new_terminal_data):
        response = requests.put(
            "{}{}{}".format(self.url, '/Terminals/', terminal_id),
            headers=self.headers,
            data=json.dumps(new_terminal_data)             
        )
        print(response.status_code)
        print(response.headers)
        print(response.content)
    
    '''Delete a terminal given its identifier "id" '''   
    def delete_terminal(self, terminal_id):
        response = requests.delete(
            "{}{}{}".format(self.url, '/Terminals/', terminal_id),
            headers=self.headers
        )
        print(response.status_code)
        print(response.headers)
        print(response.content)

#Channel
class Channel():
    def __init__(self):
        self.url = 'http://192.168.8.100:5000'
        self.headers = {'Content-Type': 'application/json' , 'X-API-KEY': 'mytoken'}
        self.nbr_Probes_max= 2
        self.counter = 0
    
    '''List all channels'''   
    def get(self):
        response = requests.get(
            "{}{}".format(self.url, '/Channels'),
            headers=self.headers
        )
        print(response.status_code)
        print(response.headers)
        print(response.content)
    
    '''create a new channel '''   
    def post_channel(self, new_channel_data):
        if self.counter < self.nbr_Probes_max :
            response = requests.post(
                "{}{}".format(self.url, '/Channels/'),
                headers=self.headers,
                data=json.dumps(new_channel_data) 
            )
            new_channel_data['id'] = self.counter = self.counter + 1
            print(response.status_code)
            print(response.headers)
            print(response.content)

    '''Show a single channel item '''     
    def get_channel(self, channel_id):
        response = requests.get(
            "{}{}{}".format(self.url, '/Channels/', channel_id),
            headers=self.headers
        )
        print(response.status_code)
        print(response.headers)
        print(response.content)
    
    '''Update a channel given its identifier "id" '''   
    def update_channel(self, channel_id, new_channel_data):
        response = requests.put(
            "{}{}{}".format(self.url, '/Channels/', channel_id),
            headers=self.headers,
            data=json.dumps(new_channel_data)             
        )
        print(response.status_code)
        print(response.headers)
        print(response.content)
    
    '''Delete a channel given its identifier "id" '''    
    def delete_channel(self, channel_id):
        response = requests.delete(
            "{}{}{}".format(self.url, '/Channels/', channel_id),
            headers=self.headers
        )
        print(response.status_code)
        print(response.headers)
        print(response.content)

if __name__ == "__main__":

    cad= Card()
    cad.get()
    cad.post_card({"Name":"Mastercard"})
    cad.post_card({"Name":"Maestro"})
    cad.post_card({"Name":"Blue visa"})
    cad.post_card({"Name":"Smartcard"})
    cad.get_card(1)
    cad.update_card( 1, {"Name":"Smartcard"})
    cad.delete_card(1)
    ter=Terminal()
    ter.get()
    ter.post_terminal({"Device_id":"1"})
    ter.post_terminal({"Device_id":"2"})
    ter.get_terminal(1)
    ter.update_terminal(1, {"Device_id":"2"})
    ter.delete_terminal(1)
    cha=Channel()
    cha.get()
    cha. post_channel({"Card_id":"1", "Terminal_id":"3"})
    cha. post_channel({"Card_id":"2", "Terminal_id":"2"})
    cha.get_channel(1)
    cha.update_channel(1, {"Card_id":"2", "Terminal_id":"2"} )
    cha.delete_channel(1)

from flask import Flask
from flask_restplus import Api, Resource, fields
from environment.instance import environment_config
from environment.instance import environment_config
from werkzeug.contrib.fixers import ProxyFix

authorizations = {
    'apikey' : {
        'type' : 'apiKey',
        'in' : 'header',
        'name' : 'X-API-KEY'
    }
}

class Server(object):
    def __init__(self):
        self.app = Flask(__name__)
        self.api = Api(self.app, 
            authorizations=authorizations,
            version='1.0', 
            title='Multiplexing API',
            description='A simple Multiplexing API', 
            doc = environment_config["swagger-url"]
        )

    def run(self):
        self.app.run(
                debug = environment_config["debug"], 
                port = environment_config["port"]
            )

server = Server()
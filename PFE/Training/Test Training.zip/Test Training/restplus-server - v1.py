
from flask import Flask,  request
from flask_restplus import Api, Resource, fields
from werkzeug.contrib.fixers import ProxyFix
from functools import wraps 

app = Flask(__name__)
app.wsgi_app = ProxyFix(app.wsgi_app)


api = Api(app, version='1.0', title='Multiplexing API',
    description='A simple Multiplexing API',
)


ns_card = api.namespace('Cards', description='Cards operations')
ns_terminal = api.namespace('Terminals', description='Terminals operations')
ns_channel = api.namespace('Channels', description='Channels operations')

card = api.model('cards', {
    'id': fields.Integer(readonly=True, description='The card unique identifier'),
    'Name': fields.String(required=True, description='The card details')
})

terminal = api.model('terminals', {
    'id': fields.Integer(readonly=True, description='The card unique identifier'),
    'Device_id': fields.String(required=True, description='The card details')
})

channel = api.model('channels', {
    'id': fields.Integer(readonly=True, description='The channel unique identifier'),
    'Card_id': fields.String(required=True, description='The channel details'),
    'Terminal_id': fields.String(required=True, description='The channel details')
})
#Cards
class CardDAO(object):
    def __init__(self):
        self.counter = 0
        self.cards = []

    def get(self, id):
        for card in self.cards:
            if card['id'] == id:
                return card
        api.abort(404, "card {} doesn't exist".format(id))

    def create(self, data):
        card = data
        card['id'] = self.counter = self.counter + 1
        self.cards.append(card)
        return card

    def update(self, id, data):
        card = self.get(id)
        card.update(data)
        return card

    def delete(self, id):
        card = self.get(id)
        self.cards.remove(card)


DAO = CardDAO()
DAO.create({'Name': 'Visa'})
DAO.create({'Name': 'MasterCard'})
DAO.create({'Name': 'Maestro'})
DAO.create({'Name': 'BlueVisa'})

@ns_card.route('/')
class CardList(Resource):
    '''Shows a list of all cards, and lets you POST to add new cards'''
    @ns_card.doc('list_cards')
    @ns_card.marshal_list_with(card, envelope='cards')
    def get(self):
        '''List all cards'''
        return DAO.cards
    
    @ns_card.doc('create_card')
    @ns_card.expect(card)
    @ns_card.marshal_with(card, code=201)
    def post(self):
        '''Create a new card'''
        return DAO.create(api.payload), 201


@ns_card.route('/<int:id>')
@ns_card.response(404, 'Card not found')
@ns_card.param('id', 'The card identifier')
class Card(Resource):
    '''Show a single card item and lets you delete them'''
    
    @ns_card.doc('get_card')
    @ns_card.marshal_with(card)
    def get(self, id):
        '''Fetch a given resource'''
        return DAO.get(id)
    
    @ns_card.doc('delete_card')
    @ns_card.response(204, 'Card deleted')
    def delete(self, id):
        '''Delete a card given its identifier'''
        DAO.delete(id)
        return '', 204
    
    @ns_card.expect(card)
    @ns_card.marshal_with(card)
    def put(self, id):
        '''Update a card given its identifier'''
        return DAO.update(id, api.payload)
        

#Terminals
class TerminalDAO(object):
    def __init__(self):
        self.counter = 0
        self.terminals = []

    def get(self, id):
        for terminal in self.terminals:
            if terminal['id'] == id:
                return terminal
        api.abort(404, "terminal {} doesn't exist".format(id))

    def create(self, data):
        terminal = data
        terminal['id'] = self.counter = self.counter + 1
        self.terminals.append(terminal)
        return terminal

    def update(self, id, data):
        terminal = self.get(id)
        terminal.update(data)
        return terminal

    def delete(self, id):
        terminal = self.get(id)
        self.terminals.remove(terminal)


DAOT = TerminalDAO()
DAOT.create({'Device_id': '1'})
DAOT.create({'Device_id': '2'})


@ns_terminal.route('/')
class TerminalList(Resource):
    '''Shows a list of all terminals, and lets you POST to add new terminals'''
    
    @ns_terminal.doc('list_terminals')
    @ns_terminal.marshal_list_with(terminal, envelope='terminals')
    def get(self):
        '''List all terminals'''
        return DAOT.terminals
     
    
    @ns_terminal.doc('create_terminal')
    @ns_terminal.expect(terminal)
    @ns_terminal.marshal_with(terminal, code=201)
    def post(self):
        '''Create a new terminal'''
        return DAOT.create(api.payload), 201


@ns_terminal.route('/<int:id>')
@ns_terminal.response(404, 'Terminal not found')
@ns_terminal.param('id', 'The terminal identifier')
class Terminal(Resource):
    '''Show a single terminal item and lets you delete them'''
    
    @ns_terminal.doc('get_terminal')
    @ns_terminal.marshal_with(terminal)
    def get(self, id):
        '''Fetch a given resource'''
        return DAOT.get(id)
     
    
    @ns_terminal.doc('delete_terminal')
    @ns_terminal.response(204, 'Terminal deleted')
    def delete(self, id):
        '''Delete a terminal given its identifier'''
        DAOT.delete(id)
        return '', 204
    
    
    @ns_terminal.expect(terminal)
    @ns_terminal.marshal_with(terminal)
    def put(self, id):
        '''Update a card given its identifier'''
        return DAOT.update(id, api.payload)


#Channels
class ChannelDAO(object):
    def __init__(self):
        self.counter = 0
        self.channels = []

    def get(self, id):
        for channel in self.channels:
            if channel['id'] == id:
                return channel
        api.abort(404, "channel {} doesn't exist".format(id))

    def create(self, data):
        channel = data
        channel['id'] = self.counter = self.counter + 1
        self.channels.append(channel)
        return channel

    def update(self, id, data):
        channel = self.get(id)
        channel.update(data)
        return channel

    def delete(self, id):
        channel = self.get(id)
        self.channels.remove(channel)


DAOC = ChannelDAO()
DAOC.create({'Card_id': '1', 'Terminal_id': '2' })
DAOC.create({'Card_id': '1', 'Terminal_id': '2' })


@ns_channel.route('/')
class ChannelList(Resource):
    '''Shows a list of all channels, and lets you POST to add new channels'''
    
    @ns_channel.doc('list_channels')
    @ns_channel.marshal_list_with(channel, envelope='channels')
    def get(self):
        '''List all channels'''
        return DAOC.channels
     
    
    @ns_channel.doc('create_channel')
    @ns_channel.expect(channel)
    @ns_channel.marshal_with(channel, code=201)
    def post(self):
        '''Create a new channel'''
        return DAOC.create(api.payload), 201


@ns_channel.route('/<int:id>')
@ns_channel.response(404, 'Channel not found')
@ns_channel.param('id', 'The channel identifier')
class Channel(Resource):
    '''Show a single channel item and lets you delete them'''
    
    @ns_channel.doc('get_channel')
    @ns_channel.marshal_with(channel)
    def get(self, id):
        '''Fetch a given resource'''
        return DAOC.get(id)
     
   
    @ns_channel.doc('delete_channel')
    @ns_channel.response(204, 'Channel deleted')
    def delete(self, id):
        '''Delete a channel given its identifier'''
        DAOC.delete(id)
        return '', 204
     
    
    @ns_channel.expect(channel)
    @ns_channel.marshal_with(channel)
    def put(self, id):
        '''Update a channel given its identifier'''
        return DAOC.update(id, api.payload)

if __name__ == '__main__':
    app.run(debug=True)
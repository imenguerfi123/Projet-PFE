# client.py
import os
import requests
from flask_restplus import Api, Resource, fields
import json
url = os.environ["SECRET_URL"]
response = requests.get(url)
 
api_key = os.environ.get('X-API-KEY')

headers = {'Content-Type': 'application/json' , 'X-API-KEY': 'mytoken'}
response= requests.headers
class CardList(Resource):
    '''Shows a list of all cards, and lets you POST to add new cards'''

    def get(self):
        '''List all cards'''
        
        response = requests.get(
            "{}{}".format(url, '/Cards'))
        print(response.status_code)
        print(response.headers)
        print (response.content)
    
    def post(self, new_card_data):
        '''Create a new card'''
        response = requests.get(
            "{}{}".format(url, '/Cards'))
        print(response.status_code)
        print(response.headers)
        print(response.body)
        data=json.dumps(new_card_data)
        response = requests.post(data)
        print(data)
      
class TerminalList(Resource):
    '''Shows a list of all cards, and lets you POST to add new cards'''

    def get(self):
        '''List all cards'''
        response = requests.get(
            "{}{}".format(url, '/Terminals'))
        print(response.status_code)
        print (response.content)      

class ChannelList(Resource):
    '''Shows a list of all cards, and lets you POST to add new cards'''

    def get(self):
        '''List all cards'''
        response = requests.get(
            "{}{}".format(url, '/Channels'))
        print(response.status_code)
        print (response.content)    
        
        
if __name__ == "__main__":
    cl= CardList()
    cl.get()
    cl.post({'id':'5', 'Name': 'Visa'})
    tl= TerminalList()
    tl.get()
    chl= ChannelList()
    chl.get()
    
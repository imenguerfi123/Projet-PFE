

pip install flask uwsgi requests


SECRET_URL="http://192.168.8.100:5000" X-API-KEY="mytoken"  python client.py

